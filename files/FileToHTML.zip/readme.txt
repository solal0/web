/!\ WARNING /!\
Original Website: https://websim.com/@CaptainSkira/file-self-downloading-html
Original Discord: https://discord.gg/6kmscdE8Qt (infinite use invite)
\!/ WARNING \!/

Hello,
Welcome to File to HTML readme file.
Here's a simple guide to help you setup and use File to HTML properly.

Note: The bigger the file, the longer everything will be, from the conversion to the download of the original file.

step 1. Download the latest version of Python from https://www.python.org/downloads/
step 2. Run python-{latest version}-amd64.exe and follow instruction
(Add Python to PATH and optionaly run installation with admin privileges)
step 3. Once Python is successfully installed place the file to convert into the folder named Original
step 4. Run builder.py and press Enter in the cmd prompt.
step 5. Once everything is done correctly, you should find YourFileName.html inside the folder named Output.

Need any further help ? Sure thing, you can join my discord server at: https://discord.gg/6kmscdE8Qt