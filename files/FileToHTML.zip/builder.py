import base64
import os
import time
import random
import sys

banner = r"""
$$$$$$$$\ $$\ $$\                   $$\                     $$\   $$\ $$$$$$$$\ $$\      $$\ $$\       
$$  _____|\__|$$ |                  $$ |                    $$ |  $$ |\__$$  __|$$$\    $$$ |$$ |      
$$ |      $$\ $$ | $$$$$$\        $$$$$$\    $$$$$$\        $$ |  $$ |   $$ |   $$$$\  $$$$ |$$ |      
$$$$$\    $$ |$$ |$$  __$$\       \_$$  _|  $$  __$$\       $$$$$$$$ |   $$ |   $$\$$\$$ $$ |$$ |      
$$  __|   $$ |$$ |$$$$$$$$ |        $$ |    $$ /  $$ |      $$  __$$ |   $$ |   $$ \$$$  $$ |$$ |      
$$ |      $$ |$$ |$$   ____|        $$ |$$\ $$ |  $$ |      $$ |  $$ |   $$ |   $$ |\$  /$$ |$$ |      
$$ |      $$ |$$ |\$$$$$$$\         \$$$$  |\$$$$$$  |      $$ |  $$ |   $$ |   $$ | \_/ $$ |$$$$$$$$\ 
\__|      \__|\__| \_______|         \____/  \______/       \__|  \__|   \__|   \__|     \__|\________|
                                                                                     _           ___ _   _          
                                                                                    | |__ _  _  / __| |_(_)_ _ __ _ 
                                                                                    | '_ \ || | \__ \ / / | '_/ _` |
                                                                                    |_.__/\_, | |___/_\_\_|_| \__,_|
                                                                                          |__/                      

Welcome to File to HTML !
A free to use tool to turn any file into a self downloading HTML.                                                                            

Press Enter to begin conversion...
"""

original_folder = "Original"
output_folder = "Output"
os.makedirs(output_folder, exist_ok=True)

print(banner)
input()
print("\nYou can sit back and relax, your file is being processed...\n")

def loading_bar(min_time=3, steps=20):
    start_time = time.time()
    for i in range(1, steps + 1):
        time.sleep(random.uniform(0.05, 0.5))
        sys.stdout.write("\r[" + "#" * i + " " * (steps - i) + "]")
        sys.stdout.flush()
    elapsed = time.time() - start_time
    if elapsed < min_time:
        time.sleep(min_time - elapsed)
    print("\n")

files = os.listdir(original_folder)
if not files:
    print("No files found in Original folder.")
    exit()

for original_file in files:
    original_path = os.path.join(original_folder, original_file)

    with open(original_path, "rb") as f:
        encoded_content = base64.b64encode(f.read()).decode()

    html_content = f"""<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Download {original_file}</title>
</head>
<body>
<script>
(function(){{
    var link = document.createElement('a');
    link.href = 'data:application/octet-stream;base64,{encoded_content}';
    link.download = '{original_file}';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
}})();
</script>
</body>
</html>"""

    output_path = os.path.join(output_folder, original_file + ".html")
    with open(output_path, "w", encoding="utf-8") as f:
        f.write(html_content)

    loading_bar(min_time=3)

    print(f"✅ Finished: {original_file} -> {output_path}\n")

print("All files have been processed successfully!")
