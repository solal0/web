import requests
import base64
import sys
import time
from tkinter import Tk
from tkinter.filedialog import askopenfilename
import os

banner = r"""
 _____ _    _            _        ______ _       _         _____                       _ _           
/  ___| |  (_)          ( )       | ___ \ |     | |       /  __ \                     (_) |Made          
\ `--.| | ___ _ __ __ _ |/ ___    | |_/ / | ___ | |__     | /  \/ ___  _ __ ___  _ __  _| | ___ b̲y__
 `--. \ |/ / | '__/ _` |  / __|   | ___ \ |/ _ \| '_ \    | |    / _ \| '_ ` _ \| '_ \| | |/ _ \ '__|Skira
/\__/ /   <| | | | (_| |  \__ \   | |_/ / | (_) | |_) |   | \__/\ (_) | | | | | | |_) | | |  __/ |   
\____/|_|\_\_|_|  \__,_|  |___/   \____/|_|\___/|_.__/     \____/\___/|_| |_| |_| .__/|_|_|\___|_|   
                                                                               | |                  
Select your golden ticket to proceed.                                          |_|                                                                                           
"""

script_dir = os.path.dirname(os.path.abspath(__file__))
output_folder = os.path.join(script_dir, "Output")
os.makedirs(output_folder, exist_ok=True)

print(banner)

def select_config_file():
    Tk().withdraw()
    file_path = askopenfilename(title="Select your golden ticket",
                                filetypes=[("Text Files", "*.txt *.json"), ("All Files", "*.*")])
    if not file_path:
        print("No golden ticket selected. Exiting...")
        sys.exit(0)
    return file_path

def load_config(file_path):
    config = {}
    try:
        with open(file_path, "r", encoding="utf-8") as f:
            code = f.read()
        exec(code, config)
        if "name" not in config or "parts" not in config:
            raise ValueError("Config file must define 'name' and 'parts'.")
        return config["name"], config["parts"]
    except Exception as e:
        print(f"Error reading config file: {e}")
        input("Press Enter to close...")
        sys.exit(1)

def get_import_speed():
    print("Choose importation speed:")
    print("1. Slow (recommended, safer for website)")
    print("2. Fast (may temporarily block your computer, use at your own risk)")
    choice = input("Enter 1 for Slow or 2 for Fast: ").strip()
    if choice == "2":
        print("Warning: Fast import may temporarily block your computer but usually works fine.")
        return "fast"
    return "slow"

def download_parts(parts, output_path, delay, retries=5, retry_delay=5):
    total_files = len(parts)

    try:
        with open(output_path, "wb") as f_out:
            for i, url in enumerate(parts, start=1):
                filename = url.split("/")[-1]
                attempt = 0
                while attempt < retries:
                    try:
                        print(f"[{i}/{total_files}] Importing {filename} ({url}) | Attempt {attempt+1}")
                        r = requests.get(url, timeout=20)
                        r.raise_for_status()
                        text = r.text.strip()
                        if text.startswith("data:application/octet-stream;base64,"):
                            text = text.split(",", 1)[1]
                        text = ''.join(text.split())
                        decoded_bytes = base64.b64decode(text)
                        f_out.write(decoded_bytes)
                        print(f"✅ Added {filename} to {output_path}\n")
                        if delay > 0:
                            time.sleep(delay)
                        break  # success, exit retry loop
                    except (requests.RequestException, base64.binascii.Error) as e:
                        attempt += 1
                        print(f"⚠️ Error with {filename}: {e}")
                        if attempt < retries:
                            print(f"Retrying in {retry_delay} seconds...")
                            time.sleep(retry_delay)
                        else:
                            print(f"❌ Failed to import {filename} after {retries} attempts.")
                            input("Press Enter to close...")
                            sys.exit(1)
    except Exception as e:
        print(f"\nError writing to file: {e}")
        input("Press Enter to close...")
        sys.exit(1)

    abs_path = os.path.abspath(output_path)
    print(f"\n🎉 All parts imported successfully! Combined file saved as: {abs_path}")
    input("Press Enter to close...")

# --- Main Script ---
config_file = select_config_file()
output_name, parts = load_config(config_file)
output_path = os.path.join(output_folder, output_name)

speed = get_import_speed()
delay = 0.5 if speed == "slow" else 0.1  # slow down a bit even for fast

download_parts(parts, output_path, delay)
