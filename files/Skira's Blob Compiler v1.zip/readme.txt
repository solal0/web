/!\ WARNING /!\
Original Website: https://websim.com/@CaptainSkira/blob-factory
Original Discord: https://discord.gg/6kmscdE8Qt (infinite use invite)
\!/ WARNING \!/

Hello,
Welcome to Skira's Blob Compiler readme file.
Here's a simple guide to help you setup and use Skira's Blob Compiler properly.

Note: The bigger the file, the longer everything will be, even if you select the second option.

step 1. Download the latest version of Python from https://www.python.org/downloads/
step 2. Run python-{latest version}-amd64.exe and follow instruction
(Add Python to PATH and optionaly run installation with admin privileges)
step 3. Once Python is successfully installed open a cmd prompt and run "pip install requests" and then "pip install tkinter"
step 4. Run compiler.py, wait for the golden ticket selecter to show up and select your Golden Ticket.json file.
step 5. Select the option you prefer and let the script do it's thing. Once done, press Enter and you should find your file inside the Output folder located in the same directory as compiler.py. Enjoy ! :D

Need any further help or having any trouble ? Sure thing, you can join my discord server at: https://discord.gg/6kmscdE8Qt