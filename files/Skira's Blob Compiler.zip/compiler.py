import requests
import base64
import sys
import time
from tkinter import Tk
from tkinter.filedialog import askopenfilename
import os
import ctypes
import zipfile
import io
import subprocess
import tempfile

# === Update Check Config ===
VERSION_FILE = "version.txt"
TOOL_URL = "https://solal0.github.io/web/files/Skira's%20Blob%20Compiler.zip"
UPDATER_URL = "https://solal0.github.io/web/files/updater.py"
INFO_FILE = os.path.join(tempfile.gettempdir(), "update_info.tmp")

def force_console_focus():
    """Force Windows console focus."""
    try:
        kernel32 = ctypes.windll.kernel32
        user32 = ctypes.windll.user32
        hWnd = kernel32.GetConsoleWindow()
        if hWnd:
            user32.ShowWindow(hWnd, 9)
            user32.SetForegroundWindow(hWnd)
    except Exception:
        pass

def run_updater():
    """Download updater.py, write info file, and run updater."""
    print("⚡ Running updater...")

    # 1. Write info file for updater (parent folder of compiler.py)
    compiler_parent = os.path.dirname(os.path.abspath(__file__))
    with open(INFO_FILE, "w", encoding="utf-8") as f:
        f.write(compiler_parent)

    # 2. Download updater.py
    try:
        r = requests.get(UPDATER_URL, timeout=20)
        r.raise_for_status()
        updater_path = os.path.join(tempfile.gettempdir(), "updater.py")
        with open(updater_path, "wb") as f:
            f.write(r.content)
    except Exception as e:
        print(f"❌ Failed to download updater.py: {e}")
        input("Press Enter to close...")
        sys.exit(1)

    # 3. Run updater.py
    try:
        subprocess.run([sys.executable, updater_path])
    except Exception as e:
        print(f"❌ Failed to run updater.py: {e}")
        input("Press Enter to close...")
        sys.exit(1)
    
    sys.exit(0)  # exit compiler.py after updater finishes

def check_for_updates():
    print("Checking for updates...")

    # 1. Check local version.txt
    if not os.path.exists(VERSION_FILE):
        print("❌ version.txt missing!")
        run_updater()

    try:
        with open(VERSION_FILE, "r", encoding="utf-8") as f:
            local_ver = f.read().strip()
    except Exception:
        print("❌ Failed to read version.txt!")
        run_updater()

    # 2. Check remote version inside ZIP
    try:
        r = requests.get(TOOL_URL, timeout=20)
        r.raise_for_status()
        with zipfile.ZipFile(io.BytesIO(r.content)) as z:
            if VERSION_FILE not in z.namelist():
                print("⚠️ Remote tool has no version.txt, skipping update check.")
                return
            remote_ver = z.read(VERSION_FILE).decode("utf-8").strip()
    except Exception as e:
        print(f"⚠️ Could not check remote version: {e}")
        return

    if local_ver != remote_ver:
        print("⚠️ Tool is outdated!")
        run_updater()
    else:
        print("✅ Tool is up to date.")

# === Banner ===
banner = r"""
 _____ _    _            _        ______ _       _         _____                       _ _           
/  ___| |  (_)          ( )       | ___ \ |     | |       /  __ \                     (_) |Made          
\ `--.| | ___ _ __ __ _ |/ ___    | |_/ / | ___ | |__     | /  \/ ___  _ __ ___  _ __  _| | ___ b̲y__
 `--. \ |/ / | '__/ _` |  / __|   | ___ \ |/ _ \| '_ \    | |    / _ \| '_ ` _ \| '_ \| | |/ _ \ '__|Skira
/\__/ /   <| | | | (_| |  \__ \   | |_/ / | (_) | |_) |   | \__/\ (_) | | | | | | |_) | | |  __/ |   
\____/|_|\_\_|_|  \__,_|  |___/   \____/|_|\___/|_.__/     \____/\___/|_| |_| |_| .__/|_|_|\___|_|   
                                                                               | |                  
Select your golden ticket to proceed.                                          |_|                                                                                           
"""

# === Ticket Handling ===
script_dir = os.path.dirname(os.path.abspath(__file__))
output_folder = os.path.join(script_dir, "Output")
os.makedirs(output_folder, exist_ok=True)

def select_ticket_file():
    Tk().withdraw()
    file_path = askopenfilename(title="Select your golden ticket",
                                filetypes=[("Golden Ticket Files", "*.golden_ticket.json *.txt"), ("All Files", "*.*")])
    if not file_path:
        print("No golden ticket selected. Exiting...")
        sys.exit(0)
    force_console_focus()
    return file_path

def load_ticket(file_path):
    try:
        with open(file_path, "r", encoding="utf-8") as f:
            lines = f.readlines()
        parts = [line.strip() for line in lines if line.strip() and not line.strip().startswith("#")]
        if not parts:
            raise ValueError("Golden ticket contains no valid links.")
        base_name = os.path.basename(file_path)
        if ".golden_ticket" in base_name:
            output_name = base_name.split(".golden_ticket")[0]
        else:
            output_name = os.path.splitext(base_name)[0]
        return output_name, parts
    except Exception as e:
        print(f"Error reading golden ticket: {e}")
        input("Press Enter to close...")
        sys.exit(1)

def format_time(seconds):
    h = int(seconds // 3600)
    m = int((seconds % 3600) // 60)
    s = int(seconds % 60)
    return f"{h:02}:{m:02}:{s:02}"

def get_import_speed(total_parts):
    slow_time = total_parts * 1.70
    fast_time = total_parts * 1.20
    print("Choose importation speed:")
    print(f"1. Slow (recommended, slower but safer.) | AVG: [{format_time(slow_time)}]")
    print(f"2. Fast (very tiny chance of the website blocking your IP) | AVG: [{format_time(fast_time)}]")
    choice = input("Enter 1 for Slow or 2 for Fast: ").strip()
    if choice == "2":
        print("⚡ Fast import selected.")
        return "fast"
    else:
        print("🐢 Slow import selected.")
        return "slow"

def download_parts(parts, output_path, delay, retries=5, retry_delay=5):
    total_files = len(parts)
    try:
        with open(output_path, "wb") as f_out:
            for i, url in enumerate(parts, start=1):
                filename = url.split("/")[-1]
                attempt = 0
                while attempt < retries:
                    try:
                        print(f"[{i}/{total_files}] Importing {filename} ({url}) | Attempt {attempt+1}")
                        r = requests.get(url, timeout=30)
                        r.raise_for_status()
                        text = r.text.strip()
                        if text.startswith("data:application/octet-stream;base64,"):
                            text = text.split(",", 1)[1]
                        text = ''.join(text.split())
                        decoded_bytes = base64.b64decode(text)
                        f_out.write(decoded_bytes)
                        print(f"✅ Added {filename} to {output_path}\n")
                        if delay > 0:
                            time.sleep(delay)
                        break
                    except (requests.RequestException, base64.binascii.Error) as e:
                        attempt += 1
                        print(f"⚠️ Error with {filename}: {e}")
                        if attempt < retries:
                            print(f"Retrying in {retry_delay} seconds...")
                            time.sleep(retry_delay)
                        else:
                            print(f"❌ Failed to import {filename} after {retries} attempts.")
                            input("Press Enter to close...")
                            sys.exit(1)
    except Exception as e:
        print(f"\nError writing to file: {e}")
        input("Press Enter to close...")
        sys.exit(1)

    abs_path = os.path.abspath(output_path)
    print(f"\n🎉 All parts imported successfully! Combined file saved as: {abs_path}")
    input("Press Enter to close...")

# === Main ===
if __name__ == "__main__":
    check_for_updates()
    print(banner)

    ticket_file = select_ticket_file()
    output_name, parts = load_ticket(ticket_file)
    output_path = os.path.join(output_folder, output_name)

    speed = get_import_speed(len(parts))
    delay = 0.5 if speed == "slow" else 0.1

    download_parts(parts, output_path, delay)
